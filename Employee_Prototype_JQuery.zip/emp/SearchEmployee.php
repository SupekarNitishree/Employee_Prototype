<?php
    include_once("connection.php");
    //echo $_GET["dob"]." ".$_GET["selectdob"];
    //di//e();

    $json = ["status"=>false];
    if(!$conn){
        echo "Database connection fail";
        die();
    }
    else{
        $sql = "SELECT * FROM emp WHERE EmpNo LIKE '".$_POST["employeeid"]."%' AND FirstName LIKE '".$_POST["firstname"]."%' AND LastName LIKE '".$_POST["lastname"]."%' ";
        if ($_POST["dob"]!='') {
            $sql = $sql." AND DOB ".$_POST["selectdob"]."'".$_POST["dob"]."'";
        }
        if ($_POST["doj"]!='') {
            $sql = $sql." AND DOJ ".$_POST["selectdoj"]."'".$_POST["doj"]."'";
        }
        $exe = $conn->query($sql);
        while ($row= $exe->fetch_assoc()) {
            $status = ["status"=>true];
            $res[] = ["EmpNo"=>$row["EmpNo"],"FirstName"=>$row["FirstName"],
                    "LastName"=>$row["LastName"],"DOB"=>$row["DOB"],"DOJ"=>$row["DOJ"]];
        }
        $arr["result"] = $res;
        $json = array_merge($status,$arr);
    }
    echo json_encode($json);
?>