<?php
    error_reporting(0);
    $host = "localhost";
    $user = "root";
    $pass = "cdacacts";
    $db = "sample";
    $conn = new mysqli($host,$user,$pass,$db);
    if ($conn->connect_error) {
        $conn=false;
    }
?>