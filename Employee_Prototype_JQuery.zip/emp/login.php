<?php
    include_once("connection.php");
    $json = ["status"=>false];
    if ($_POST["username"]!='' && $_POST["password"]!='') {
        $sql = "SELECT EmpNo, CONCAT(FirstName,' ', LastName) AS Name FROM emp WHERE EmpNo = '".$_POST["username"]."' AND Password = '".$_POST["password"]."';";
        $exe = $conn->query($sql);
        if ($row= $exe->fetch_assoc()) {
            $json = ["status"=>true,"Name"=>$row["Name"]];
            session_start();
            $_SESSION["username"] = $row["Name"];
        }
    }
    echo json_encode($json);
?>