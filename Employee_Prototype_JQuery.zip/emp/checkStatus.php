<?php
    $json = ["status"=>false];
    session_start();
    if(isset($_SESSION['username'])){
        $json = ["status"=>true,"username"=>$_SESSION['username']];
    }
    echo json_encode($json);
?>