$(function () {
    $.ajax({
        url: "checkStatus.php"
    }).done(function(data) {
        var result = JSON.parse(data);
        if(!result.status){
          location.href = "EmployeeMaintenanceHome.html";
        }
        else $("#user").text(" "+result.username);
    });
});