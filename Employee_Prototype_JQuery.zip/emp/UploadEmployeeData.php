<?php
    $json = ["status"=>false];
    if($_FILES['file']!=''){
		$file = $_FILES['file']['name'];
		$type = $_FILES['file']['type'];
		$temfile = $_FILES['file']['tmp_name'];
		// Get file extension
		$extension = strtolower(substr($file,strpos($file,'.')+1));
		// Check extension & set location 
		if($extension=='jpg'||$extension=='jpeg'||$extension=='png'||$type=='image/jpeg'){
			$location = "upload/img/";
		}else if($extension=='docx'|| $extension=='xlsx'|| $extension=='pptx' || $extension=='txt'){
			$location = "upload/doc/";
		}else if($extension=='pdf'){
			$location = "upload/pdf/";
		}else{
			$location = "upload/other/";
		}
		// Upload file to location
		if(move_uploaded_file($temfile,$location.$file)){
			$json = ["status"=>true];
        }
    }
    echo json_encode($json);
?>