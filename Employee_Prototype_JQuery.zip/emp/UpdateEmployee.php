<?php
    include_once("connection.php");
    $json = ["status"=>false];
    if ($_POST["employeeid"]!='') {
        $sql = "UPDATE emp SET FirstName = '".$_POST["firstname"]."', LastName = '".$_POST["lastname"]."', DOB = '".$_POST["dob"]."', DOJ = '".$_POST["doj"]."' WHERE EmpNo = '".$_POST["employeeid"]."'";
        if ($conn->query($sql)==TRUE) {
            $json = ["status"=>true];
        }
    }
    echo json_encode($json);
?>